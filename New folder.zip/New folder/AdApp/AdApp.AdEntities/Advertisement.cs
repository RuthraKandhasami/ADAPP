﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdApp.AdEntities
{[Serializable]
    public class Advertisement
    {
       
        
            public string AdverId { get; set; }
            public string AdverName { get; set; }
            public string AdverMode { get; set; }
            public string FromDate { get; set; }
            public string ToDate { get; set; }
            public string AdverDuration { get; set; }
            public int Cost { get; set; }
        }
    }

