﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AdApp.AdEntities;
using AdApp.HandlingException;
using AdApp.DAL;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace AdApp.AdBL
{
    public class BusinessLayer
    {
        public static List<Advertisement> advertisementList = new List<Advertisement>();

        public bool AddAdvertisementDAL(Advertisement newAdvertisement)
        {
            bool advertisementAdded = false;
            try
            {
                advertisementList.Add(newAdvertisement);

                advertisementAdded = true;
            }
            catch (SystemException e)
            {
                throw new Exception(e.Message);
            }
            return advertisementAdded;
        }
        public Advertisement SearchAdvertisementDAL(string searchAdverID)
        {
            Advertisement searchAdvertisement = null;
            try
            {
                searchAdvertisement = advertisementList.Find(advertisement => advertisement.AdverId == searchAdverID);
            }
            catch (SystemException e)
            {
                throw new Exception(e.Message);
            }
            return searchAdvertisement;
        }
        public bool UpdateAdvertisementDAL(Advertisement updateAdvertisement)
        {
            bool advertisementUpdated = false;
            try
            {
                for (int i = 0; i < advertisementList.Count; i++)
                {
                    if (advertisementList[i].AdverId == updateAdvertisement.AdverId)
                    {
                        updateAdvertisement.AdverName = advertisementList[i].AdverName;
                        updateAdvertisement.AdverMode = advertisementList[i].AdverMode;
                        updateAdvertisement.FromDate = advertisementList[i].FromDate;
                        updateAdvertisement.ToDate = advertisementList[i].ToDate;
                        updateAdvertisement.AdverDuration = advertisementList[i].AdverDuration;
                        advertisementUpdated = true;
                    }
                }

            }
            catch (SystemException e)
            {
                throw new Exception(e.Message);
            }
            return advertisementUpdated;
        }
        public bool DeleteUpdateDAL(string deleteAdverID)
        {
            bool advertisementDeleted = false;
            try
            {
                Advertisement deleteAdvertisement = advertisementList.Find(advertisement => advertisement.AdverId == deleteAdverID);

                if (deleteAdverID != null)
                {
                    advertisementList.Remove(deleteAdvertisement);
                    advertisementDeleted = true;

                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return advertisementDeleted;

        }
        public List<Advertisement> GetAllGuestDAL()
        {
            return advertisementList;
        }

        public bool SerializeAdvertisementDAL()
        {
            bool serializedAdvertisement = false;
            try
            {
                FileStream objFS = new FileStream(@"D:\serializationGuest.dat", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
                BinaryFormatter objBinF = new BinaryFormatter();
                objBinF.Serialize(objFS, advertisementList);
                objFS.Close();
                serializedAdvertisement = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return serializedAdvertisement;
        }
        public List<Advertisement> DeSerializeGuestDAL()
        {

            FileStream objFS = new FileStream(@"D:\serializationGuest.dat", FileMode.Open, FileAccess.Read, FileShare.Read);
            BinaryFormatter binary = new BinaryFormatter();
            List<Advertisement> objNewAdvertisement = binary.Deserialize(objFS) as List<Advertisement>;
            objFS.Close();
            return objNewAdvertisement;



        }
    }
}
